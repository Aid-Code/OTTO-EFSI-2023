streaming_data.py
==================

.. literalinclude:: ../../../../examples_linux/streaming_data.py
    :language: python
    :caption: examples_linux/streaming_data.py
    :linenos:
    :lineno-match:
